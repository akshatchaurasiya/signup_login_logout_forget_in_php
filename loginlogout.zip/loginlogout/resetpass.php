<?php
$name   = $_GET['name'];
$email  =$_GET['email'];
// print_r($name);
// print_r($email);
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>update</title>
<link rel="stylesheet" href="style2.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
<style>
@import url('https://fonts.googleapis.com/css2?family=Fredericka+the+Great&display=swap');
</style>
</head>
<body oncontextmenu="return false">

  <form class="container3" method="POST" name="myform" action="resetpass2.php" autocomplete="off" oncontextmenu="return false">
    
    <!-- Reset form -->
    <h1>Reset Password</h1>

    <label for="name"><b>Name</b></label>
    <input type="text" value="<?php echo $name; ?>" disabled />

    <input type="hidden" name="name" id="name" value="<?php echo $name; ?>" />
    <input type="hidden" name="email" id="email" value="<?php echo $email; ?>" />


    <label for="email"><b>Email</b></label>
    <input type="email" name="email" value="<?php echo $email ?>" disabled />


    <label for="pass"><b>Enter new password</b></label><span class="error">*<?php echo $passErr;?></span>
    <input type="password" placeholder="Enter Password" name="pass" id="pass" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,12}" spellcheck="false" required>
    <i class="far fa-eye" id="togglePassword" style="position: absolute; margin-top: 5%; margin-left: -6%; cursor: pointer;"></i>

    <div class="pm">Password must have at least <b>one Number</b>, <b>one Uppercase</b> and <b>Lowercase</b> letter, and <b>Minimum 8 Characters</b></div>

 
    <label for="cpss"><b>Confirm Password</b></label><span class="error">*<?php echo $cpassErr;?></span>
    <input type="password" placeholder="Enter Confirm Password" name="cpass" id="cpass" spellcheck="false" required>

    <label for="capt"><b>Captcha</b></label><span class="error">*</span>
    <input type="texts" id="capt" name="capt" class="capt" readonly><a class="re" onclick="cap()">Refresh</a>

    <input type="text" id="textinput" name="textinput" maxlength="6" placeholder="Enter Captcha code" spellcheck="false" required>

    <button class="btn" type="submit" name="submit" id="submit">Update</button>
    <div class="ex2"><a href="login.php">login here</a></div>

  </form>



<script type="text/javascript">

//for captcha

function cap() {
  var alpha=['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','!','@','#','$','%','^','&','*','(',')','-','+'];


  var a=alpha[Math.floor(Math.random()*74)];
  var b=alpha[Math.floor(Math.random()*74)];
  var c=alpha[Math.floor(Math.random()*74)];
  var d=alpha[Math.floor(Math.random()*74)];
  var e=alpha[Math.floor(Math.random()*74)];
  var f=alpha[Math.floor(Math.random()*74)];

  /*document.write(a);
  document.write(b);
  document.write(d);
  document.write(e);
  document.write(c);
  document.write(f);*/

  var sum=a+b+c+d+e+f;

  //document.write(sum);

  document.getElementById("capt").value=sum;
}
//end captcha code...

//for show password code
  const togglePassword = document.querySelector('#togglePassword');
  const password = document.querySelector('#pass');
 
  togglePassword.addEventListener('click', function (e) {
    // toggle the type attribute
    const type = pass.getAttribute('type') === 'password' ? 'texts' : 'password';
    pass.setAttribute('type', type);
    // toggle the eye slash icon
    this.classList.toggle('fa-eye-slash');
  });
  //end show pass code


//for copy paste in input field and call captcha
window.onload = () => {
  cap();  //for catpcha

  //for name input copy paste off
  const name = document.getElementById('name');
  name.onpaste = e => e.preventDefault();
  name.oncopy = e => e.preventDefault();


  //for email input copy paste off
  const email = document.getElementById('email');
  email.onpaste = e => e.preventDefault();
  email.oncopy = e => e.preventDefault();


  //for pass input copy paste off
  const pass = document.getElementById('pass');
  pass.onpaste = e => e.preventDefault();
  pass.oncopy = e => e.preventDefault();


  //for cpass input copy paste off
  const cpass = document.getElementById('cpass');
  cpass.onpaste = e => e.preventDefault();
  cpass.oncopy = e => e.preventDefault();


  //for capt input copy paste off
  const capt = document.getElementById('capt');
  capt.oncopy = e => e.preventDefault();


  //for textinput input copy paste off
  const textinput = document.getElementById('textinput');
  textinput.onpaste = e => e.preventDefault();
  textinput.oncopy = e => e.preventDefault();
}
//end disable copy paste code


</script>
</body>
</html>