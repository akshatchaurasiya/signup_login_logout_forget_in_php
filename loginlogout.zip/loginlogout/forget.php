<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>forget</title>
<link rel="stylesheet" href="style2.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
<style>
@import url('https://fonts.googleapis.com/css2?family=Fredericka+the+Great&display=swap');
</style>
</head>
<body oncontextmenu="return false">

  <form class="container2" method="POST" name="myform" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" autocomplete="off" oncontextmenu="return false">
    
    <h1 id="forget">Forget Password</h1>
    <label for="name"><b>Name</b></label><span class="error">*<?php echo $nameErr;?></span>
    <input type="text" placeholder="Enter Name" name="name" id="name" onkeypress="return event.charCode >= 97 && event.charCode <= 122 || event.charCode >= 65 && event.charCode <= 90 || event.charCode==32" spellcheck="false" required>


    <label for="email"><b>Email</b></label><span class="error">*<?php echo $emailErr;?></span>
    <input type="email" placeholder="Enter Email" name="email" id="email" pattern="[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$" spellcheck="false" required>


    <label for="capt"><b>Captcha</b></label><span class="error">*</span>
    <input type="texts" id="capt" name="capt" class="capt" readonly><a class="re" onclick="cap()">Refresh</a>

    <input type="text" id="textinput" name="textinput" maxlength="6" placeholder="Enter Captcha code" spellcheck="false" required>



    <div class="ex1">
      <input type="radio" name="radio" id="new" value="new" required="required" />
      <label for="new">Create new password</label>

      <input type="radio" name="radio" id="old" value="old" required="required" />
      <label for="old">Get old password</label>
    </div>

    <button type="submit" class="btn" id="myBtn">Submit</button>
    <div class="ex2"><a href="login.php">login here</a></div>
  </form>



<script type="text/javascript">
//for captcha

function cap() {
  var alpha=['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','!','@','#','$','%','^','&','*','(',')','-','+'];


  var a=alpha[Math.floor(Math.random()*74)];
  var b=alpha[Math.floor(Math.random()*74)];
  var c=alpha[Math.floor(Math.random()*74)];
  var d=alpha[Math.floor(Math.random()*74)];
  var e=alpha[Math.floor(Math.random()*74)];
  var f=alpha[Math.floor(Math.random()*74)];

  /*document.write(a);
  document.write(b);
  document.write(d);
  document.write(e);
  document.write(c);
  document.write(f);*/

  var sum=a+b+c+d+e+f;

  //document.write(sum);

  document.getElementById("capt").value=sum;
}
//end captcha code...


//for copy paste in input field and call captcha
window.onload = () => {
  cap();  //for catpcha

  //for name input copy paste off
  const name = document.getElementById('name');
  name.onpaste = e => e.preventDefault();
  name.oncopy = e => e.preventDefault();


  //for email input copy paste off
  const email = document.getElementById('email');
  email.onpaste = e => e.preventDefault();
  email.oncopy = e => e.preventDefault();


  //for capt input copy paste off
  const capt = document.getElementById('capt');
  capt.oncopy = e => e.preventDefault();


  //for textinput input copy paste off
  const textinput = document.getElementById('textinput');
  textinput.onpaste = e => e.preventDefault();
  textinput.oncopy = e => e.preventDefault();
}
//end disable copy paste code


</script>
</body>
</html>


<?php require 'logincon.php';

$name       = $_POST['name'];
$email      = $_POST['email'];
$capt       = $_POST['capt'];
$textinput  = $_POST['textinput'];
$radio      = $_POST['radio'];

/*echo $name."<br>";
echo $email."<br>";
echo $capt."<br>";
echo $textinput."<br>";
echo $radio;*/

if ($capt != $textinput) {
  echo '<script>alert("Please Enter a valid Captcha")</script>';?>
  <script type="text/javascript">window.location=history.back(); </script><?php
} else {
  if($radio == 'old') {
    $result = mysqli_query($CFG,"SELECT * FROM login_form WHERE email='" . $email . "' and name = '". $name ."'");
    $row  = mysqli_fetch_array($result);

    $email = $row['email'];
    $pwd = $row['pass'];
    echo "<div id='getpass'>Your password is encrypted in <b>md5</b> formate<br> 
          Your password is <span class='error'><b>$pwd</b></span><br> 
          Your email is: <span class='error'><b>$email</b></span><br> 
          <a href = 'https://md5.gromweb.com/?md5=$pwd' target='_blank'>click here  for decrypted</a></div>";  
  }

  if($radio == 'new') {
    $result = mysqli_query($CFG,"SELECT * FROM login_form WHERE email='" . $email . "' and name = '". $name ."'");
    $row  = mysqli_fetch_array($result);
    if($row) {
      header('Location: resetpass.php?name='.$name.'&email='.$email);
    } else {
      echo '<script>alert("Please Enter correct details.")</script>';
    }

  }
}


?>
