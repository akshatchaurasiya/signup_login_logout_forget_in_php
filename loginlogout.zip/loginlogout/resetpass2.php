<?php require 'logincon.php';

$name   = $_POST['name'];
$email  = $_POST['email'];
$pass   = $_POST['pass'];
$cpass  = $_POST['cpass'];
$str1   = $_POST['capt'];
$str2   = $_POST['textinput'];

// var_dump($name);
// var_dump($email);
// var_dump($pass);
// var_dump($cpass);
// var_dump($str1);
// var_dump($str2);
// exit;

if($name!= null && $email!=null && $pass!=null && $cpass!=null && $str1!=null && $str2!=null) {
  if ($pass!=$cpass) {
    echo '<script>alert("Your Password not Matched")</script>';?>
    <script type="text/javascript">window.location=history.back(); </script><?php
  } else {
    if ($str1==$str2) {
      $pwd =md5($cpass);
      $sql = "UPDATE login_form SET pass='$pwd' WHERE name = '$name' AND email = '$email'";
  } else {
      echo '<script>alert("Please Enter a valid Captcha")</script>';?>
      <script type="text/javascript">window.location=history.back(); </script><?php
    }
  }
} else {
  echo '<script>alert("Enter your details")</script>';
}

if(mysqli_query($CFG, $sql)) {
  echo '<script>alert("your password successfully updated Please login")</script>';?>
  <script type="text/javascript">window.location='login.php';</script><?php
} else {
  // echo "Error: " . $sql . "<br>" . $CFG->error;
  header('location:forget.php');
  echo '<script>alert("ERROR: Your password is not updated")</script>';
}
?>