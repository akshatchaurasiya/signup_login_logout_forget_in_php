<?php
global $CFG;

$host="localhost";
$user="root";
$pass="leooffice";
$db="Chaurasiya_DB";

$CFG=mysqli_connect($host, $user, $pass, $db);

if(!$CFG)
{
  die("Connection failed");
}
// echo "Connected"."<br>";

?>