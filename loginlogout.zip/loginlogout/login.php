<?php require 'logincon.php';

    session_start();
    $message="";
    if(count($_POST)>0) {
        // $CFG = mysqli_connect('localhost','root','leooffice','Chaurasiya_DB') or die('Unable To connect');
        $password=$_POST['pass'];
        $pwd = md5($password);


        $result = mysqli_query($CFG,"SELECT * FROM login_form WHERE email='" . $_POST["email"] . "' and pass = '". $pwd ."'");

        $row  = mysqli_fetch_array($result);
        if(is_array($row)) {
          if ($_POST['capt'] == $_POST['textinput']) {
            $_SESSION["id"] = $row['id'];
            $_SESSION["name"] = $row['name'];
          } else{
            $message = "Enter valid Captcha<br>";
          }
        } else {
          $message = "Invalid Email or Password!<br>";
        }
    }
    if(isset($_SESSION["id"])) {
      /*$_SESSION['start'] = time(); 
      // Destroying session after 1 minute
      $_SESSION['expire'] = $_SESSION['start'] + (1 * 5);*/
      header('Location:index.php');
    }
?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Login</title>
<link rel="stylesheet" type="text/css" href="style2.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
</head>
<body oncontextmenu="return false">

  <form action="" method="post" class="container2">
    <h1>Login</h1>

    <center><label style="color: red;">
      <?php if($message!="") { echo $message; } ?>
      </label></center>

    <label for="email"><b>Email</b></label><span class="error">*</span>
    <input type="text" placeholder="Enter Email" name="email" pattern="[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$" id="email" required>

    <label for="pass"><b>Password </b></label><span class="error">*</span>
    <input type="password" placeholder="Enter Password" name="pass" id="pass" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,12}" id="pass" required>
    <i class="far fa-eye" id="togglePassword" style="position: absolute; margin-top: -10%; margin-left: 87%; cursor: pointer;"></i>


    <label for="capt"><b>Captcha</b></label><span class="error">*</span>
    <input type="texts" id="capt" name="capt" class="capt" readonly><a class="re" onclick="cap()">Refresh</a>

    <input type="text" id="textinput" name="textinput" maxlength="6" placeholder="Enter Captcha code" spellcheck="false" required>


    <input type="checkbox" checked="checked" name="remember"> Remember me
    <a href="forget.php" class="forget">Forget Password</a>

    <button type="submit" class="btn">Login</button>
    <div class="ex2">Not registered? <a href="signup.php">Create an account</a></div>
  </form>




<script>

//for captcha

function cap() {
  var alpha=['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','!','@','#','$','%','^','&','*','(',')','-','+'];


  var a=alpha[Math.floor(Math.random()*74)];
  var b=alpha[Math.floor(Math.random()*74)];
  var c=alpha[Math.floor(Math.random()*74)];
  var d=alpha[Math.floor(Math.random()*74)];
  var e=alpha[Math.floor(Math.random()*74)];
  var f=alpha[Math.floor(Math.random()*74)];

  /*document.write(a);
  document.write(b);
  document.write(d);
  document.write(e);
  document.write(c);
  document.write(f);*/

  var sum=a+b+c+d+e+f;

  //document.write(sum);

  document.getElementById("capt").value=sum;
}
//end captcha code...\




  //for show pass code
  const togglePassword = document.querySelector('#togglePassword');
  const password = document.querySelector('#pass');
 
  togglePassword.addEventListener('click', function (e) {
    // toggle the type attribute
    const type = pass.getAttribute('type') === 'password' ? 'texts' : 'password';
    pass.setAttribute('type', type);
    // toggle the eye slash icon
    this.classList.toggle('fa-eye-slash');
  });
  //end code for show pass



  //for disable copy paste in input field
  window.onload = () => {

    cap();  //for catpcha

    //for email input copy paste off
    const email = document.getElementById('email');
    email.onpaste = e => e.preventDefault();
    email.oncopy = e => e.preventDefault();

    //for pass input copy paste off
    const pass = document.getElementById('pass');
    pass.onpaste = e => e.preventDefault();
    pass.oncopy = e => e.preventDefault();

    //for capt input copy paste off
    const capt = document.getElementById('capt');
    capt.oncopy = e => e.preventDefault();


    //for textinput input copy paste off
    const textinput = document.getElementById('textinput');
    textinput.onpaste = e => e.preventDefault();
    textinput.oncopy = e => e.preventDefault();
  }
  //end code for disable copy pase

</script>
</body>
</html>